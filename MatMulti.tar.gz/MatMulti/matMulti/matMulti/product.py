import numpy as np

def product(matrix1, matrix2):
    result = np.dot(matrix1, matrix2)
    return result


